# esp32-i2s-sdcard-wav-player
How to use Arduino ESP32 I2S to play wav music file from sdcard

Full demo here: http://www.iotsharing.com/2017/07/how-to-use-arduino-esp32-i2s-to-play-wav-music-from-sdcard.html
